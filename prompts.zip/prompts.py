def create_health_assessment(age_sup, muscle_bal, chronic):
    """건강 지표 평가를 딕셔너리로 생성"""
    return {
        "노화 억제 분석지수": age_sup,
        "근육 밸런스 지수": muscle_bal,
        "만성질환 억제지수": chronic
    }

def parse_health_keywords(user_input):
    """사용자 입력에서 건강 키워드를 추출"""
    if not user_input:
        return []
    
    # 쉼표로 구분된 키워드들을 분리하고 공백 제거
    keywords = [keyword.strip() for keyword in user_input.split(',') if keyword.strip()]
    
    # 만약 쉼표가 없다면 전체를 하나의 키워드로 처리
    if not keywords and user_input.strip():
        keywords = [user_input.strip()]
    
    return keywords

def get_system_message():
    return "당신은 Amway 건강 제품 추천 전문가입니다. 사용자의 건강 지표와 관심사를 바탕으로 최적의 제품을 추천해드립니다."

def get_product_explanation_prompt(product_row):
    """제품 설명을 위한 프롬프트 생성"""
    return f"""
    다음은 건강 기능성 보조제 추천 결과입니다.
    제품명: {product_row['제품명']}
    식품유형: {product_row['식품유형']}
    관리 필요 영역: {product_row['관리 필요 영역']}
    식약처 인정 기능성: {product_row['식약처 인정 기능성']}
    주요 특징: {product_row['주요 특징']}
    섭취 방법: {product_row['섭취 방법']}
    주의사항: {product_row['주의사항']}
    원재료: {product_row['원재료']}
    추천 근거: {product_row.get('매칭_근거', '정보 없음')}
    우선순위 점수: {product_row.get('우선순위_점수', 0)}

    위 정보를 바탕으로 이 제품이 사용자에게 적합한 이유를 3줄 이내로 설명해 주세요.
    """

def get_product_tip_prompt(product_row, health_indicators, management_areas):
    """제품별 TIP 생성을 위한 프롬프트"""
    return f"""
    다음은 건강 기능성 보조제에 대한 정보입니다:
    
    제품명: {product_row['제품명']}
    해당 건강지표: {health_indicators}
    관리 필요 영역: {management_areas}
    식약처 인정 기능성: {product_row.get('식약처 인정 기능성', '정보 없음')}
    주요 특징: {product_row.get('주요 특징', '정보 없음')}
    원재료: {product_row.get('원재료', '정보 없음')}
    
    위 정보를 바탕으로 이 제품의 효과와 건강 관리 팁을 포함한 
    하나의 완전한 TIP 설명을 작성해주세요. 
    
    요구사항:
    1. [TIP] 형식으로 시작하지 말고 내용만 작성
    2. 반드시 하나의 문단으로만 작성 (줄바꿈 없이)
    3. 제품의 주요 효과와 건강상 이점만 포함
    4. 복용법, 섭취 방법, 주의사항 등은 제외
    5. 구체적인 수치(예: 120mg, 34mg 등)는 포함하지 말 것
    6. 2-3줄 정도의 적절한 길이로 작성하되 한 문단으로 연결
    7. 부드럽고 자연스러운 문체 사용
    8. 절대 여러 문단으로 나누지 말 것
    9. 제품 설명부분에 한자, 일본어는 사용하지 말 것
    """

def get_health_expert_system_message():
    """건강기능식품 전문가 시스템 메시지"""
    return """당신은 건강기능식품 전문가입니다. 
    
사용자의 건강 상태와 선택된 건강 지표를 고려하여 제품의 효과와 사용법에 대해 
전문적이고 이해하기 쉽게 설명해주세요.

다음 사항들을 포함하여 설명해주세요:
1. 제품의 주요 효과와 작용 원리
2. 해당 건강 지표와의 연관성
3. 사용 시 주의사항과 권장사항
4. 일상생활에서 실천할 수 있는 건강 관리 팁

설명은 친근하고 이해하기 쉬운 톤으로 작성하되, 전문성을 잃지 않도록 해주세요."""